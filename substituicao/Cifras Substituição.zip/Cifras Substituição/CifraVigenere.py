class Vigenere:

    def __init__(self):
        self.alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def repetir_senha(self, texto, senha):
        texto = texto.replace(' ', '')
        if len(senha)<len(texto):
            while len(texto)>len(senha):
                for letra in senha:
                    senha += letra
                    if len(senha)==len(texto):
                        break
        return senha

    def codificar(self, texto, senha):
        texto = texto.replace(' ', '')
        senha = self.repetir_senha(texto, senha)
        texto_codificado = ""
        for i in range(len(senha)):
            idx = int(self.alfabeto.find(senha[i].upper()))
            texto_codificado += self.cifracesar(texto[i], idx)
        return texto_codificado

    def decodificar(self, texto, senha):
        texto = texto.replace(' ', '')
        senha = self.repetir_senha(texto, senha)
        texto_codificado = ""
        for i in range(len(senha)):
            idx = int(self.alfabeto.find(senha[i].upper()))
            texto_codificado += self.cifracesar_decodificar(texto[i], idx)
        return texto_codificado

    def cifracesar(self, text, rotn):
        rotn = rotn%26
        text = list(text)
        for i in range(0, len(text)):
            if (ord(text[i]) >= 65 and ord(text[i]) <= 90):
                text[i] = chr(ord(text[i]) + rotn)
                if (ord(text[i]) > 90):
                    text[i] = chr(ord(text[i]) % 90 + 64)
            elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                text[i] = chr(ord(text[i]) + rotn)
                if (ord(text[i]) > 122):
                    text[i] = chr(ord(text[i]) % 122 + 96)
        texto_cesar = ''.join(text)
        return texto_cesar

    def cifracesar_decodificar(self, text, rotn):
        rotn = rotn % 26
        text = list(text)
        for i in range(0, len(text)):
            if (ord(text[i]) >= 65 and ord(text[i]) <= 90):
                # text[i] = chr(ord(text[i]))
                if ((ord(text[i]) - rotn) < 65):
                    text[i] = chr(ord(text[i]) + 26 - rotn)
                else:
                    text[i] = chr(ord(text[i]) - rotn)
            elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                text[i] = chr(ord(text[i]))
                if ((ord(text[i]) - rotn) < 97):
                    text[i] = chr(ord(text[i]) + 26 - rotn)
                else:
                    text[i] = chr(ord(text[i]) - rotn)
        texto_cesar = ''.join(text)
        return texto_cesar

    """PROGRAMA PRINCIPAL"""


print("*  BEM VINDO AO PROGRAMA DE CIFRA VIGENÉRE")
print("ATENÇÃO O ALFABETO DISPONÍVEL SE ENCONTRA ENTRE [ABCDEFGHIJKLMNOPQRSTUVWXYZ] QUALQUER CARACTER FORA ESSES SERÁ DESCONSIDERADO \n")
texto = input("Digite o texto que será cifrado ou decifrado: ")
chave = input("Digite uma chave: ")
opcao = int(input("Digite 1 para codificar e 2 para decodificar: "))
if opcao==1:
    print("O texto cifrado é", Vigenere().codificar(texto, chave))
elif opcao==2:
    print("O texto decifrado é", Vigenere().decodificar(texto, chave))
