class Polibio:

    def __init__(self):
        self.alfabeto = "ABCDEFGHIJKLMNOPRSTUVWXYZ"
        self.alfapolibio = ['11', '12', '13', '14', '15', '21', '22', '23', '24', '25', '31', '32', '33', '34', '35', '41', '42', '43', '44', '45', '51', '52', '53', '54', '55']
                    #        a       b    c    d     e     f     g      h    i      j     k    l      m     n    o      p     r     s     t     u    v     w     x     y      z
    def codificar(self, texto):
        texto = ''.join(texto.upper())
        texto = texto.replace(' ', '')
        texto_codificado=""
        for letra in texto:
            if letra == "Q":
                letra = "K"
            idx = int(self.alfabeto.find(letra))
            texto_codificado += self.alfapolibio[idx]+ " "
        return texto_codificado

    def decodificar(self, codigo):
        texto_decodificado = ""
        codigo = codigo.replace(' ', '')
        for i in range(0, len(codigo)-1, 2):
            idx = int(self.alfapolibio.index(codigo[i:i+2]))
            texto_decodificado += self.alfabeto[idx]
        return texto_decodificado

"""PROGRAMA PRINCIPAL"""
print("""*   BEM VINDO AO PROGRAMA DE CÓGIDO POLÍBIO
OS CARACTERES DISPONIVEIS SÃO ABCDEFGHIJKLMNOPQRSTUVWXYZ E 11 12 13 14 15 21 22 23 24 25 31 32 33 34 35 41 42 43 44 45 51 52 53 54 55
\n \n""")
opcao = int(input("Digite 1 para codificar(apenas letras) e digite 2 para decodificar(apenas números): "))
if opcao==1:
    texto = input("Digite a frase que deseja codiicar: ")
    print("O resultado da codificação é", Polibio().codificar(texto))
elif opcao==2:
    texto = input("Digite o código que deseja decodificar: ")
    print("O resultado da decodificação é", Polibio().decodificar(texto))
