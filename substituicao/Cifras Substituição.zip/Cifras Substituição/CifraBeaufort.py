class Beaufort:

    def __init__(self):
        self.alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        self.numeros = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]

    def repetir_senha(self, texto, senha):
        texto = texto.replace(' ', '')
        if len(senha)<len(texto):
            while len(texto)>len(senha):
                for letra in senha:
                    senha += letra
                    if len(senha)==len(texto):
                        break
        return senha

    def codificar(self, texto, senha):
        texto = texto.replace(' ', '')
        senha = self.repetir_senha(texto, senha)
        texto_codificado = ""
        for i in range(len(senha)):
            idx = int(self.numeros[self.alfabeto.find(senha[i].upper())])
            idx2 = int(self.numeros[self.alfabeto.find(texto[i].upper())])
            dif_idxs = int(idx-idx2)%26
            if idx2<0:
                aux = self.cifracesar_decodificar(texto[i], dif_idxs*-1)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
            else:
                aux = self.cifracesar(texto[i], dif_idxs)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
        return texto_codificado.upper()

    def codificar_segundaforma(self, texto, senha):
        texto = texto.replace(' ', '')
        senha = self.repetir_senha(texto, senha)
        texto_codificado = ""
        aux = senha
        senha = texto
        texto = aux
        for i in range(len(senha)):
            idx = int(self.numeros[self.alfabeto.find(senha[i].upper())])
            idx2 = int(self.numeros[self.alfabeto.find(texto[i].upper())])
            dif_idxs = int(idx-idx2)%26
            if idx2<0:
                aux = self.cifracesar_decodificar(texto[i], dif_idxs*-1)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
            else:
                aux = self.cifracesar(texto[i], dif_idxs)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
        return texto_codificado.upper()

    def decodificar(self, texto, senha):
        texto = texto.replace(' ', '')
        senha = self.repetir_senha(texto, senha)
        texto_codificado = ""
        for i in range(len(senha)):
            idx = int(self.numeros[self.alfabeto.find(senha[i].upper())])
            idx2 = int(self.numeros[self.alfabeto.find(texto[i].upper())])
            dif_idxs = int(idx - idx2) % 26
            if idx2 < 0:
                aux = self.cifracesar_decodificar(texto[i], dif_idxs * -1)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
            else:
                aux = self.cifracesar(texto[i], dif_idxs)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
        return texto_codificado.upper()

    def decodificar_segundaforma(self, texto, senha):
        texto = texto.replace(' ', '')
        senha = self.repetir_senha(texto, senha)
        texto_codificado = ""
        aux = senha
        senha = texto
        texto = aux
        for i in range(len(senha)):
            idx = int(self.numeros[self.alfabeto.find(senha[i].upper())])
            idx2 = int(self.numeros[self.alfabeto.find(texto[i].upper())])
            dif_idxs = int(idx + idx2)%26
            if idx2 < 0:
                aux = self.cifracesar_decodificar(texto[i], dif_idxs * -1)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
            else:
                aux = self.cifracesar(texto[i], dif_idxs)
                texto_codificado += self.cifracesar_decodificar(aux, idx2)
        return texto_codificado.upper()

    def cifracesar(self, text, rotn):
        rotn = rotn%26
        text = list(text)
        for i in range(0, len(text)):
            if (ord(text[i]) >= 65 and ord(text[i]) <= 90):
                text[i] = chr(ord(text[i]) + rotn)
                if (ord(text[i]) > 90):
                    text[i] = chr(ord(text[i]) % 90 + 64)
            elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                text[i] = chr(ord(text[i]) + rotn)
                if (ord(text[i]) > 122):
                    text[i] = chr(ord(text[i]) % 122 + 96)
        texto_cesar = ''.join(text)
        return texto_cesar

    def cifracesar_decodificar(self, text, rotn):
        rotn = rotn % 26
        text = list(text)
        for i in range(0, len(text)):
            if (ord(text[i]) >= 65 and ord(text[i]) <= 90):
                # text[i] = chr(ord(text[i]))
                if ((ord(text[i]) - rotn) < 65):
                    text[i] = chr(ord(text[i]) + 26 - rotn)
                else:
                    text[i] = chr(ord(text[i]) - rotn)
            elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                text[i] = chr(ord(text[i]))
                if ((ord(text[i]) - rotn) < 97):
                    text[i] = chr(ord(text[i]) + 26 - rotn)
                else:
                    text[i] = chr(ord(text[i]) - rotn)
        texto_cesar = ''.join(text)
        return texto_cesar


"""PROGRAMA PRINCIPAL"""
print("""**                            PROGRAMA DE CIFRA DE BEAUFORT
OS CARACTERES DISPONIVEIS SÃO [ABCDEFGHIJKLMNOPQRSTUVWXYZ] QUALQUER CARACTER QUE NÃO FOREM ESTES, SERÃO DESCONSIDERADOS
\n
\n""")
texto = input("Digite o texto: ")
chave = input("Digite a chave: ")
opcao = int(input("Digite 1 para criptografar e 2 para decifrar: "))
if opcao==1:
    forma = int(input("Digite 1 para criptografar pela primeira forma e 2 para criptografar pela segunda forma: "))
    if forma==1:
        print("A frase criptograda é", Beaufort().codificar(texto, chave))
    elif forma==2:
        print("A frase criptograda é", Beaufort().codificar_segundaforma(texto, chave))
elif opcao==2:
    forma = int(input("Digite 1 para descriptografar pela primeira forma e 2 para descriptografar pela segunda forma: "))
    if forma==1:
        print("A frase descriptograda é", Beaufort().decodificar(texto, chave))
    elif forma==2:
        print("A frase descriptograda é", Beaufort().decodificar_segundaforma(texto, chave))
