class OTP:

    def __init__(self):
        self.alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def codificar(self, texto, chave):
        texto = texto.replace(' ', '').upper()
        chave = chave.replace(' ', '').upper()
        frase_codificada=""
        for i in range (len(chave)):
            idx = (self.alfabeto.find(texto[i]) + self.alfabeto.find(chave[i]))%26
            frase_codificada += self.alfabeto[idx]
        return frase_codificada

    def decodificar(self, texto, chave):
        texto = texto.replace(' ', '').upper()
        chave = chave.replace(' ', '').upper()
        frase_codificada = ""
        for i in range(len(chave)):
            idx = (self.alfabeto.find(texto[i]) - self.alfabeto.find(chave[i])) % 26
            if idx<0:
                idx = idx*-1
            frase_codificada += self.alfabeto[idx]
        return frase_codificada

"""PROGRAMA PRINCIPAL"""
print("*                       BEM VINDO AO PROGRAMA DE CIFRA ON-TIME-PAD")
print("ATENÇÃO O ALFABETO DISPONÍVEL SE ENCONTRA ENTRE [ABCDEFGHIJKLMNOPQRSTUVWXYZ] QUALQUER CARACTER FORA ESSES SERÁ DESCONSIDERADO \n")
texto = input("Digite o texto que será cifrado ou decifrado: ")
chave = input("Digite uma chave: ")
opcao = int(input("Digite 1 para codificar e 2 para decodificar: "))
if opcao==1:
    print("O texto cifrado é", OTP().codificar(texto, chave))
elif opcao==2:
    print("O texto decifrado é", OTP().decodificar(texto, chave))
