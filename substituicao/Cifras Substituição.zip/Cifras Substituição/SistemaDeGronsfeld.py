class Gronsfeld:

    def __init__(self):
        self.alfabeto = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def codificar(self, texto, chave):
        texto = texto.replace(' ', '').upper()
        chave = self.repetir_senha(texto, chave)
        texto = list(texto)
        for i in range(len(chave)):
            rotn = int(chave[i])
            if (ord(texto[i]) >= 65 and ord(texto[i]) <= 90):
                texto[i] = chr(ord(texto[i]) + rotn)
                if (ord(texto[i]) > 90):
                    texto[i] = chr(ord(texto[i]) % 90 + 64)
            elif (ord(texto[i]) >= 97 and ord(texto[i]) <= 122):
                texto[i] = chr(ord(texto[i]) + rotn)
                if (ord(texto[i]) > 122):
                    texto[i] = chr(ord(texto[i]) % 122 + 96)
        return ''.join(texto)

    def decodificar(self, texto, chave):
        texto = texto.replace(' ', '').upper()
        chave = self.repetir_senha(texto, chave)
        texto = list(texto)
        for i in range(len(chave)):
            rotn = int(chave[i])
            if (ord(texto[i]) >= 65 and ord(texto[i]) <= 90):
                if ((ord(texto[i]) - rotn) < 65):
                    texto[i] = chr(ord(texto[i]) + 26 - rotn)
                else:
                    texto[i] = chr(ord(texto[i]) - rotn)
            elif (ord(texto[i]) >= 97 and ord(texto[i]) <= 122):
                texto[i] = chr(ord(texto[i]))
                if ((ord(texto[i]) - rotn) < 97):
                    texto[i] = chr(ord(texto[i]) + 26 - rotn)
                else:
                    texto[i] = chr(ord(texto[i]) - rotn)
        return ''.join(texto)

    def repetir_senha(self, texto, senha):
        texto = texto.replace(' ', '')
        if len(senha)<len(texto):
            while len(texto)>len(senha):
                for letra in senha:
                    senha += letra
                    if len(senha)==len(texto):
                        break
        return senha

"""PROGRAMA PRINCIPAL"""
print("*  BEM VINDO AO PROGRAMA DE SISTEMA DE GRONSFELD")
print("ATENÇÃO O ALFABETO DISPONÍVEL SE ENCONTRA ENTRE [ABCDEFGHIJKLMNOPQRSTUVWXYZ] QUALQUER CARACTER FORA ESSES SERÁ DESCONSIDERADO \n")
texto = input("Digite o texto que será cifrado ou decifrado: ")
chave = input("Digite uma chave (somente números): ")
opcao = int(input("Digite 1 para codificar e 2 para decodificar: "))
if opcao==1:
    print("O texto cifrado é", Gronsfeld().codificar(texto, chave))
elif opcao==2:
    print("O texto decifrado é", Gronsfeld().decodificar(texto, chave))
