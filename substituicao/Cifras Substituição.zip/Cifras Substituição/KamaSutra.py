class KamaSutra:

    def __init__(self):
        self.alfabeto = "ADHIKMORSUWYZVXBGJCQLNEFPT"
        self.alfakama = "VXBGJCQLNEFPTADHIKMORSUWYZ"

    def criptar(self, texto):
        txtcifrado = ""
        texto = texto.upper()
        for letra in texto:
            if (self.alfabeto.find(letra) == -1):
                txtcifrado += letra
            else:
                pos = self.alfabeto.find(letra)
                txtcifrado += self.alfakama[pos]
        return txtcifrado.upper()

    def decifrar(self, texto):
        return self.criptar(texto).upper()

#PROGRAMA PRINCIPAL
leia = input
opcao = 0
print("    CIFRA KAMA SUTRA")
print("O ALFABETO DISPONIVEL NESSA CIFRA É ADHIKMORSUWYZ, QUALQUER CARACTER DIFERENTE SERÁ DESCONSIDERADO\n")
texto = leia("Digite o texto que será criptografado ou decifrado: ")
while opcao != 1 and opcao != 2:
    opcao = int(leia("""\n
(1) criptografar
(2) descriptografar
Digite uma opção válida: """))
if opcao == 1:
    print("A mensagem criptografada é", KamaSutra().criptar(texto))
else:
    print("A mensagem decifrada é", KamaSutra().decifrar(texto))
