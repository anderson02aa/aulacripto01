import numpy as np
class CifraHill:

    def __init__(self):
        self.alfa = "ZABCDEFGHIJKLMNOPQRSTUVWXYZ"

    def montar_matriz(self, chave1, chave2):
        matriz = np.array([[1,3], [2,1]])
        chave = np.array([[chave1], [chave2]])

        resultado = matriz.dot(chave)
        resultado[0][0] = ((resultado[0][0])%26)
        resultado[1][0] = ((resultado[1][0])%26)
        return resultado

    def repetir_caractere(self, palavra):
        palavra = palavra.replace(' ', '').upper()
        if (len(palavra)%2 == 1):
            palavra += palavra[len(palavra)-1]
        return palavra

    def criptografar(self, palavra):
        palavra = self.repetir_caractere(palavra)
        resultado = ""
        for i in range(0, len(palavra)-1, 2):
            idx1 = int(self.alfa.find(palavra[i]))
            idx2 = int(self.alfa.find(palavra[i + 1]))
            valor_matriz = self.montar_matriz(idx1, idx2)
            letra1 = self.alfa[valor_matriz[0][0]]
            letra2 = self.alfa[valor_matriz[1][0]]
            resultado += letra1+letra2
            resultado += " "
        return resultado.replace(' ', '')

"""PROGRAMA PRINCIPAL"""

resp = 0
print("*  BEM VINDO AO PROGRAMA DE CIFRA HILL")
print("ATENÇÃO O ALFABETO DISPONÍVEL SE ENCONTRA ENTRE [ABCDEFGHIJKLMNOPQRSTUVWXYZ] QUALQUER CARACTER FORA ESSES SERÁ DESCONSIDERADO \n")
while (resp==0):
    opcao = int(input("Digite 1 para codificar e para 2 finalizar "))
    texto = input("Digite o texto que será cifrado: ")
    if opcao==1:
        print("O texto cifrado é", CifraHill().criptografar(texto))
        print("")
    elif opcao==2:
        break


