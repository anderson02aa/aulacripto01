class DellaPorta:

    def __init__(self):
        self.chaves = {
        'A': 0, 'B': 0, 'C': 1, 'D': 1, 'E': 2, 'F': 2,
        'G': 3, 'H': 3, 'I': 4, 'J': 4, 'K': 5, 'L': 5,
        'M': 6, 'N': 6, 'O': 7, 'P': 7, 'Q': 8, 'R': 8,
        'S': 9, 'T': 9, 'U': 10, 'V': 10, 'W': 11,
        'X': 11, 'Y': 12, 'Z': 12
        }
        self.alfabeto =  'ABCDEFGHIJKLM'
        self.alfacifra = 'NOPQRSTUVWXYZ'

    def deslocamento(self, senha):
        desloc = self.chaves[senha]
        return self.alfacifra[desloc:] + self.alfacifra[:desloc]

    def repetir_senha(self, texto, senha):
        texto = texto.replace(' ', '')
        if len(senha)<len(texto):
            while len(texto)>len(senha):
                for letra in senha:
                    senha += letra
                    if len(senha)==len(texto):
                        break
        return senha.upper()

    def codificar(self, texto, senha):
        frase_criptada = ""
        senha = self.repetir_senha(texto, senha)
        texto = texto.replace(' ', '').upper()

        for i in range(len(texto)):
            alfabeto_deslocado = self.deslocamento(senha[i])
            if texto[i] in self.alfabeto:
                idx = self.alfabeto.find(texto[i])
                frase_criptada += alfabeto_deslocado[idx]
            elif texto[i] in alfabeto_deslocado:
                idx = alfabeto_deslocado.find(texto[i])
                frase_criptada += self.alfabeto[idx]
        return frase_criptada

    def decodificar(self, texto, senha):
        frase_decodificada = self.codificar(texto, senha)
        return frase_decodificada

print("*                           BEM VINDO AO PROGRAMA DE CIFRA DELLA PORTA ")
print("ATENÇÃO O ALFABETO DISPONÍVEL SE ENCONTRA ENTRE [ABCDEFGHIJKLMNOPQRSTUVWXYZ] QUALQUER CARACTER FORA ESSES SERÁ DESCONSIDERADO \n")
texto = input("Digite o texto que será cifrado ou decifrado: ")
chave = input("Digite uma chave: ")
opcao = int(input("Digite 1 para codificar e 2 para decodificar: "))
if opcao==1:
    print("O texto cifrado é", DellaPorta().codificar(texto, chave))
elif opcao==2:
    print("O texto decifrado é", DellaPorta().decodificar(texto, chave))
