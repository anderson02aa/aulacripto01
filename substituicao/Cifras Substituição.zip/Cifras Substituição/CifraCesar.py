print("        ** CIFRA DE CESAR ** \n")
print("""Atenção
Os caracteres disponíveis são: (ABCDEFGHIJKLMNOPQRSTUVWXYZ) e (abcdefghijklmnopqrstuvwxyz)
Qualquer caracter que não esteja dentro dessa lista serão desconsiderados""")
resp = 0

while (resp==0):
    print("Se você deseja criptografar digite (1)")
    print("Se você deseja descriptografar digite (2)")
    cd = int(input("(1) / (2): "))
    if (cd ==1):
        text = list(input("Digite a frase que será criptografada: "))
        rotn = int(input("Digite o deslocamento [3]: "))
        rotn = rotn%26
        for i in range(0, len(text)):
                if (ord(text[i]) >= 65 and ord(text[i]) <=90):
                    text[i] = chr(ord(text[i])+rotn)
                    if (ord(text[i])>90):
                        text[i] = chr(ord(text[i])%90+64)
                elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                    text[i] = chr(ord(text[i]) + rotn)
                    if (ord(text[i])>122):
                        text[i] = chr(ord(text[i])%122+96)
        print("A frase criptografada é", ''.join(text))
    elif (cd ==2):
        text = list(input("Digite a frase que será criptografada: "))
        rotn = int(input("Digite o deslocamento [3]: "))
        rotn = rotn%26
        for i in range(0, len(text)):
            if (ord(text[i]) >= 65 and ord(text[i]) <= 90):
                #text[i] = chr(ord(text[i]))
                if ((ord(text[i])-rotn) < 65):
                    text[i] = chr(ord(text[i])+26-rotn)
                else:
                    text[i] = chr(ord(text[i])-rotn)
            elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                text[i] = chr(ord(text[i]))
                if ((ord(text[i])-rotn) < 97):
                    text[i] = chr(ord(text[i])+26-rotn)
                else:
                    text[i] = chr(ord(text[i])-rotn)
        print("A frase decodificada é ",''.join(text))
    print()
    resp = int(input("Deseja continuar? 0:(SIM) 1(Não)"))

