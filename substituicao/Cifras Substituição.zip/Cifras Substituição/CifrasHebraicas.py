class CifrasHebraicas:

    def criptar(self, texto, cifra):
        txtcifrado = ''
        texto = texto.upper()
        for ch in texto:
            if self.alfabeto.find(ch) == -1:
                 txtcifrado += ch
            else:
                pos = self.alfabeto.find(ch)
                txtcifrado += cifra[pos]
        return txtcifrado

    def decifrar(self, texto, cifra):
        return self.criptar(texto, cifra).upper()

    def __init__(self):
        self.alfabeto = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    #PROGRAMA PRINCIPAL
atbash = 'ZYXWVUTSRQPONMLKJIHGFEDCBA'
albam = 'NOPQRSTUVWXYZABCDEFGHIJKLM'
atbah = 'IHGFNDCBARQPOEMLKJZYXWVUTS'
cifras = [atbash, albam, atbah]
opcao = 0
texto = ""
resp = 0
print("Bem vindo ao programa de Cifras Hebraicas\n")
print("O alfabeto disponivel é ABCDEFGHIJKLMNOPQRSTUVWXYZ")
texto = input("Digite o texto que deseja criptografar ou descriptografar: ")
while (opcao != 1 and opcao != 2 and opcao != 3):
    opcao = int(input("""(1) Atbash
(2) Albam
(3) Atbah
Escolha uma das alternativas: """))

while (resp != 1 and resp != 2):
    resp = int(input("""\n(1) para criptografar
(2) para descriptografar
Entre com uma resposta: """))
if (resp==1):
    print("\nO seu texto criptografado é",CifrasHebraicas().criptar(texto, cifras[opcao-1]))
else:
    print("\nO texto decifrado é", CifrasHebraicas().decifrar(texto, cifras[opcao-1]))
