print("     *Codificador ZenitPolar\n")
print(""" Atenção os caracteres que serão codificados são (Z E N I T P O L A R) e (z e n i t p o l a r)
Qualquer caractere que não esteja incluido nessa lista será repetido.
""")
texto = list(input("Digite um texto: "))
print("A frase codificada é: ", end="")
for z in texto:
    if (z=='z'):
        print("p", end="")
    elif (z=='e'):
        print("o", end="")
    elif (z == 'n'):
        print("l", end="")
    elif (z == 'i'):
        print("a", end="")
    elif (z == 't'):
        print("r", end="")
    elif (z == 'p'):
        print("z", end="")
    elif (z == 'o'):
        print("e", end="")
    elif (z == 'l'):
        print("n", end="")
    elif (z == 'a'):
        print("i", end="")
    elif (z=='r'):
        print('t', end="")
    elif (z =="Z"):
        print("P", end="")
    elif (z == 'E'):
        print("O", end="")
    elif (z == 'N'):
        print("L", end="")
    elif (z == 'I'):
        print("A", end="")
    elif (z == 'T'):
        print("R", end="")
    elif (z == 'P'):
        print("Z", end="")
    elif (z == 'O'):
        print("E", end="")
    elif (z == 'L'):
        print("N", end="")
    elif (z == 'A'):
        print("I", end="")
    elif (z == 'R'):
        print('T', end="")
    else:
        print(z, end="")
        
print("\n\n")

