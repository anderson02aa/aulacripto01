print("        * ROT13  \n")
print("""Atenção
Os caracteres disponíveis são: (ABCDEFGHIJKLMNOPQRSTUVWXYZ) e (abcdefghijklmnopqrstuvwxyz)
Qualquer caracter que não esteja dentro dessa lista serão desconsiderados""")
resp = 0

while (resp==0):
    print("Para criptografar digite (1)")
    print("Para descriptografar digite (2)")
    cd = int(input("1 ou 2: "))
    if (cd == 1):
        text = list(input("Digite a frase que será codificada: "))
        for i in range(0, len(text)):
                if (ord(text[i]) >= 65 and ord(text[i]) <=90):
                    text[i] = chr(ord(text[i])+13)
                    if (ord(text[i])>90):
                        text[i] = chr(ord(text[i])%90+64)
                elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                    text[i] = chr(ord(text[i]) + 13)
                    if (ord(text[i])>122):
                        text[i] = chr(ord(text[i])%122+96)
        print("A frase criptografada é", ''.join(text))
    elif (cd ==2):
        text = list(input("Digite a frase que será codificada: "))
        for i in range(0, len(text)):
            if (ord(text[i]) >= 65 and ord(text[i]) <= 90):
                if ((ord(text[i])-13) < 65):
                    text[i] = chr(ord(text[i])+26-13)
                else:
                    text[i] = chr(ord(text[i])-13)
            elif (ord(text[i]) >= 97 and ord(text[i]) <= 122):
                text[i] = chr(ord(text[i]))
                if ((ord(text[i])-13) < 97):
                    text[i] = chr(ord(text[i])+26-13)
                else:
                    text[i] = chr(ord(text[i])-13)
        print("A frase decodificada é ",''.join(text))
    print()
    resp = int(input("Deseja continuar? 0:(SIM) 1(Não)"))