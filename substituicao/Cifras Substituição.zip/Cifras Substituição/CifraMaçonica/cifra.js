function limpar(){
    document.getElementById("limpar").onclick = function () {

    var el = document.querySelector("[class='3']");
    var pa = el ? el.parentNode : null;

    if (pa) {
        pa.removeChild(el);
    }

    };
}
function letraA(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraA.gif' class='3'>"
}
function letraB(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraB.gif' class='3'>"
}
function letraC(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraC.gif' class='3'>"
}
function letraD(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraD.gif' class='3'>"
}
function letraE(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraE.gif' class='3'>"
}
function letraF(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraF.gif' class='3'>"
}
function letraG(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraG.gif' class='3'>"
}
function letraH(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraH.gif' class='3'>"
}
function letrai(){
    document.getElementById("res").innerHTML += "<img src='imagens/Letrai.gif' class='3'>"
}
function letraJ(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraJ.gif' class='3'>"
}
function letraK(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraK.gif' class='3'>"
}
function letraL(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraL.gif' class='3'>"
}
function letraM(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraM.gif' class='3'>"
}
function letraN(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraN.gif' class='3'>"
}
function letraO(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraO.gif' class='3'>"
}
function letraP(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraP.gif' class='3'>"
}
function letraQ(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraQ.gif' class='3'>"
}
function letraR(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraR.gif' class='3'>"
}
function letraS(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraS.gif' class='3'>"
}

function letraT(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraT.gif' class='3'>"
}
function letraU(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraU.gif' class='3'>"
}
function letraV(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraV.gif' class='3'>"
}
function letraW(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraW.gif' class='3'>"
}
function letraX(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraX.gif' class='3'>"
}
function letraY(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraY.gif' class='3'>"
}
function letraZ(){
    document.getElementById("res").innerHTML += "<img src='imagens/LetraZ.gif' class='3'>"
}

function limpar2(){
    document.getElementById("res2").innerHTML = ""
}
function lA(){
    document.getElementById("res2").innerHTML += "A"
}
function lB(){
    document.getElementById("res2").innerHTML += "B"
}
function lC(){
    document.getElementById("res2").innerHTML += "C"
}
function lD(){
    document.getElementById("res2").innerHTML += "D"
}
function lE(){
    document.getElementById("res2").innerHTML += "E"
}
function lF(){
    document.getElementById("res2").innerHTML += "F"
}
function lG(){
    document.getElementById("res2").innerHTML += "G"
}
function lH(){
    document.getElementById("res2").innerHTML += "H"
}
function li(){
    document.getElementById("res2").innerHTML += "I"
}
function lJ(){
    document.getElementById("res2").innerHTML += "J"
}
function lK(){
    document.getElementById("res2").innerHTML += "K"
}
function lL(){
    document.getElementById("res2").innerHTML += "L"
}
function lM(){
    document.getElementById("res2").innerHTML += "M"
}
function lN(){
    document.getElementById("res2").innerHTML += "N"
}
function lO(){
    document.getElementById("res2").innerHTML += "O"
}
function lP(){
    document.getElementById("res2").innerHTML += "P"
}
function lQ(){
    document.getElementById("res2").innerHTML += "Q"
}
function lR(){
    document.getElementById("res2").innerHTML += "R"
}
function lS(){
    document.getElementById("res2").innerHTML += "S"
}
function lT(){
    document.getElementById("res2").innerHTML += "T"
}
function lU(){
    document.getElementById("res2").innerHTML += "U"
}
function lV(){
    document.getElementById("res2").innerHTML += "V"
}
function lW(){
    document.getElementById("res2").innerHTML += "W"
}
function lX(){
    document.getElementById("res2").innerHTML += "X"
}
function lY(){
    document.getElementById("res2").innerHTML += "Y"
}
function lZ(){
    document.getElementById("res2").innerHTML += "Z"
}